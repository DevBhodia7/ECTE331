package Part2_Threads;

/**
 * This is my main class for Problem 2.
 * It creates the shared data, starts Thread A and Thread B, and checks the final values.
 */
public class Problem2App {

    public static void main(String[] args) throws InterruptedException {
        int iterations = readIterations(args);

        System.out.println("Problem 2: Threads Synchronisation and Communication");
        System.out.println("Iterations = " + iterations);
        System.out.println("Flow shown for iteration 1 only");
        System.out.println("Expected values: " + ExpectedValues.asString());
        System.out.println();

        // This object stores A1, A2, A3, B1, B2, and B3.
        SharedData data = new SharedData();

        // This object stores the semaphores used between the two threads.
        SyncCoordinator sync = new SyncCoordinator();

        // I keep the worker objects so I can read the pass/fail count after join().
        ThreadAWorker threadA = new ThreadAWorker(data, sync, iterations);
        ThreadBWorker threadB = new ThreadBWorker(data, sync, iterations);

        long startTime = System.currentTimeMillis();

        // Both threads are started. The operating system may schedule them in any order.
        threadA.start();
        threadB.start();

        // join() makes the main thread wait until both worker threads are finished.
        threadA.join();
        threadB.join();

        long endTime = System.currentTimeMillis();

        System.out.println();
        System.out.println("Passed iterations = " + threadA.getPassedIterations());
        System.out.println("Failed iterations = " + threadA.getFailedIterations());
        System.out.println("Final shared values: " + data.valuesAsString());
        System.out.println("Execution time = " + (endTime - startTime) + " ms");

        // The test is passed only if every iteration produced the correct values.
        if (threadA.getFailedIterations() == 0 && threadA.getPassedIterations() == iterations) {
            System.out.println("Verification: PASSED");
        } else {
            System.out.println("Verification: FAILED");
        }
    }

    /**
     * I use one optional argument only.
     * If no argument is given, the program runs 100000 iterations.
     */
    private static int readIterations(String[] args) {
        if (args.length == 0) {
            return 100000;
        }

        try {
            int value = Integer.parseInt(args[0]);
            if (value > 0) {
                return value;
            }
        } catch (NumberFormatException e) {
            // If the argument is not a number, I just use the default value.
        }

        return 100000;
    }

    /**
     * I made this synchronized so Thread A and Thread B do not print on the same line.
     * The flow is printed only for iteration 1 to keep the output short.
     */
    public static synchronized void printFlow(int iteration, String message) {
        if (iteration == 1) {
            System.out.println("[Iteration " + iteration + "] " + message);
        }
    }
}