package Part2_Threads;

import java.util.concurrent.Semaphore;

/**
 * This class contains the semaphores used to control the order between both threads.
 */
public class SyncCoordinator {
    // Each semaphore starts at 0, so acquire() will block until release() is called.
    private final Semaphore a1Done = new Semaphore(0);
    private final Semaphore b2Done = new Semaphore(0);
    private final Semaphore a2Done = new Semaphore(0);
    private final Semaphore b3Done = new Semaphore(0);

    public void signalA1Done() {
        // This means FuncA1 is finished and FuncB2 is allowed to continue.
        a1Done.release();
    }

    public void waitForA1Done() throws InterruptedException {
        // Thread B waits here because FuncB2 needs A1.
        a1Done.acquire();
    }

    public void signalB2Done() {
        // This means FuncB2 is finished and FuncA2 is allowed to continue.
        b2Done.release();
    }

    public void waitForB2Done() throws InterruptedException {
        // Thread A waits here because FuncA2 needs B2.
        b2Done.acquire();
    }

    public void signalA2Done() {
        // This means FuncA2 is finished and FuncB3 is allowed to continue.
        a2Done.release();
    }

    public void waitForA2Done() throws InterruptedException {
        // Thread B waits here because FuncB3 needs A2.
        a2Done.acquire();
    }

    public void signalB3Done() {
        // This means FuncB3 is finished and FuncA3 is allowed to continue.
        b3Done.release();
    }

    public void waitForB3Done() throws InterruptedException {
        // Thread A waits here because FuncA3 needs B3.
        b3Done.acquire();
    }
}