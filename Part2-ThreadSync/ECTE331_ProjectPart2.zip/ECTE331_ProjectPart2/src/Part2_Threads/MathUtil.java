package Part2_Threads;

/**
 * This class has the summation method required in the project.
 */
public class MathUtil {

    private MathUtil() {
        // This is a utility class, so I do not create MathUtil objects.
    }

    /**
     * This method calculates 0 + 1 + 2 + ... + n using a loop.
     */
    public static int sumTo(int n) {
        int sum = 0;

        // I used a loop because the project asks for the summation to be coded using a loop.
        for (int i = 0; i <= n; i++) {
            sum = sum + i;
        }

        return sum;
    }
}