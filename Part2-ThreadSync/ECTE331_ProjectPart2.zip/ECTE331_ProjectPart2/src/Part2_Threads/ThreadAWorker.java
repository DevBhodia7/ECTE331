package Part2_Threads;

/**
 * This thread runs the three A functions in order: FuncA1, FuncA2, and FuncA3.
 */
public class ThreadAWorker extends Thread {
    private final SharedData data;
    private final SyncCoordinator sync;
    private final int iterations;

    private int passedIterations;
    private int failedIterations;

    public ThreadAWorker(SharedData data, SyncCoordinator sync, int iterations) {
        super("Thread A");
        this.data = data;
        this.sync = sync;
        this.iterations = iterations;
    }

    @Override
    public void run() {
        try {
            for (int iteration = 1; iteration <= iterations; iteration++) {

                // FuncA1 has no dependency, so Thread A can calculate it first.
                flow(iteration, "FuncA1 started");
                funcA1();
                flow(iteration, "FuncA1 finished, A1 = " + data.getA1());

                // B2 needs A1, so I release this semaphore after A1 is ready.
                flow(iteration, "A1 is ready, so Thread B can do FuncB2");
                sync.signalA1Done();

                // A2 needs B2, so Thread A blocks here until Thread B finishes B2.
                flow(iteration, "waiting for FuncB2 before FuncA2");
                sync.waitForB2Done();

                // Now B2 is ready, so FuncA2 can safely use it.
                flow(iteration, "FuncA2 started");
                funcA2();
                flow(iteration, "FuncA2 finished, A2 = " + data.getA2());

                // B3 needs A2, so I signal Thread B after A2 is ready.
                flow(iteration, "A2 is ready, so Thread B can do FuncB3");
                sync.signalA2Done();

                // A3 needs B3, so Thread A waits until Thread B finishes B3.
                flow(iteration, "waiting for FuncB3 before FuncA3");
                sync.waitForB3Done();

                // Now B3 is ready, so FuncA3 can calculate the final A value.
                flow(iteration, "FuncA3 started");
                funcA3();
                flow(iteration, "FuncA3 finished, A3 = " + data.getA3());

                // I check every iteration because the project asks for a high-iteration test.
                checkIteration(iteration);
            }
        } catch (InterruptedException e) {
            // This keeps the interrupt information if the thread is stopped while waiting.
            Thread.currentThread().interrupt();
            System.out.println("Thread A was interrupted.");
        }
    }

    private void funcA1() {
        // A1 = sum from 0 to 500.
        data.setA1(MathUtil.sumTo(500));
    }

    private void funcA2() {
        // A2 = B2 + sum from 0 to 300.
        data.setA2(data.getB2() + MathUtil.sumTo(300));
    }

    private void funcA3() {
        // A3 = B3 + sum from 0 to 400.
        data.setA3(data.getB3() + MathUtil.sumTo(400));
    }

    private void checkIteration(int iteration) {
        if (ExpectedValues.matches(data)) {
            passedIterations++;
        } else {
            failedIterations++;
            Problem2App.printFlow(iteration, "CHECK FAILED: " + data.valuesAsString());
        }

        // I print iteration 1 for the flow and the final iteration for the final proof.
        if (iteration == 1 || iteration == iterations) {
            System.out.println("[Iteration " + iteration + "] CHECK values: " + data.valuesAsString());
        }
    }

    private void flow(int iteration, String message) {
        Problem2App.printFlow(iteration, "Thread A -> " + message);
    }

    public int getPassedIterations() {
        return passedIterations;
    }

    public int getFailedIterations() {
        return failedIterations;
    }
}