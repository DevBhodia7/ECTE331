package Part2_Threads;

/**
 * This class stores the shared variables used by Thread A and Thread B.
 */
public class SharedData {
    private int a1;
    private int a2;
    private int a3;
    private int b1;
    private int b2;
    private int b3;

    // The set methods update the shared values calculated by the functions.
    public synchronized void setA1(int value) {
        a1 = value;
    }

    public synchronized void setA2(int value) {
        a2 = value;
    }

    public synchronized void setA3(int value) {
        a3 = value;
    }

    public synchronized void setB1(int value) {
        b1 = value;
    }

    public synchronized void setB2(int value) {
        b2 = value;
    }

    public synchronized void setB3(int value) {
        b3 = value;
    }

    // The get methods are synchronized because both threads read these values.
    public synchronized int getA1() {
        return a1;
    }

    public synchronized int getA2() {
        return a2;
    }

    public synchronized int getA3() {
        return a3;
    }

    public synchronized int getB1() {
        return b1;
    }

    public synchronized int getB2() {
        return b2;
    }

    public synchronized int getB3() {
        return b3;
    }

    /**
     * I use this to print all final values in one line.
     */
    public synchronized String valuesAsString() {
        return "A1=" + a1
                + ", B1=" + b1
                + ", B2=" + b2
                + ", A2=" + a2
                + ", B3=" + b3
                + ", A3=" + a3;
    }
}