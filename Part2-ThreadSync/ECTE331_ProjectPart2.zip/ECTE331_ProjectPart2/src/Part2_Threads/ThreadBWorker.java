package Part2_Threads;

/**
 * This thread runs the three B functions in order: FuncB1, FuncB2, and FuncB3.
 */
public class ThreadBWorker extends Thread {
    private final SharedData data;
    private final SyncCoordinator sync;
    private final int iterations;

    public ThreadBWorker(SharedData data, SyncCoordinator sync, int iterations) {
        super("Thread B");
        this.data = data;
        this.sync = sync;
        this.iterations = iterations;
    }

    @Override
    public void run() {
        try {
            for (int iteration = 1; iteration <= iterations; iteration++) {

                // FuncB1 has no dependency on Thread A.
                flow(iteration, "FuncB1 started");
                funcB1();
                flow(iteration, "FuncB1 finished, B1 = " + data.getB1());

                // B2 needs A1, so Thread B waits here until Thread A signals A1 done.
                flow(iteration, "waiting for FuncA1 before FuncB2");
                sync.waitForA1Done();

                // Now A1 is ready, so FuncB2 can safely use A1.
                flow(iteration, "FuncB2 started");
                funcB2();
                flow(iteration, "FuncB2 finished, B2 = " + data.getB2());

                // A2 needs B2, so I signal Thread A after B2 is ready.
                flow(iteration, "B2 is ready, so Thread A can do FuncA2");
                sync.signalB2Done();

                // B3 needs A2, so Thread B waits until Thread A finishes A2.
                flow(iteration, "waiting for FuncA2 before FuncB3");
                sync.waitForA2Done();

                // Now A2 is ready, so FuncB3 can safely use it.
                flow(iteration, "FuncB3 started");
                funcB3();
                flow(iteration, "FuncB3 finished, B3 = " + data.getB3());

                // A3 needs B3, so I signal Thread A after B3 is ready.
                flow(iteration, "B3 is ready, so Thread A can do FuncA3");
                sync.signalB3Done();
            }
        } catch (InterruptedException e) {
            // This keeps the interrupt information if the thread is stopped while waiting.
            Thread.currentThread().interrupt();
            System.out.println("Thread B was interrupted.");
        }
    }

    private void funcB1() {
        // B1 = sum from 0 to 250.
        data.setB1(MathUtil.sumTo(250));
    }

    private void funcB2() {
        // B2 = A1 + sum from 0 to 200.
        data.setB2(data.getA1() + MathUtil.sumTo(200));
    }

    private void funcB3() {
        // B3 = A2 + sum from 0 to 400.
        data.setB3(data.getA2() + MathUtil.sumTo(400));
    }

    private void flow(int iteration, String message) {
        Problem2App.printFlow(iteration, "Thread B -> " + message);
    }
}