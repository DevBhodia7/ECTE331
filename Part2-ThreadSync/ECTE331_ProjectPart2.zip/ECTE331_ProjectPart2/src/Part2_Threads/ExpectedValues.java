package Part2_Threads;

/**
 * This class stores the correct values that the program should produce.
 */
public class ExpectedValues {
    public static final int A1 = MathUtil.sumTo(500);
    public static final int B1 = MathUtil.sumTo(250);
    public static final int B2 = A1 + MathUtil.sumTo(200);
    public static final int A2 = B2 + MathUtil.sumTo(300);
    public static final int B3 = A2 + MathUtil.sumTo(400);
    public static final int A3 = B3 + MathUtil.sumTo(400);

    private ExpectedValues() {
        // I do not need objects from this class.
    }

    /**
     * This method checks if the actual shared data matches the expected values.
     */
    public static boolean matches(SharedData data) {
        return data.getA1() == A1
                && data.getB1() == B1
                && data.getB2() == B2
                && data.getA2() == A2
                && data.getB3() == B3
                && data.getA3() == A3;
    }

    /**
     * I use this to print the expected values at the start of the program.
     */
    public static String asString() {
        return "A1=" + A1
                + ", B1=" + B1
                + ", B2=" + B2
                + ", A2=" + A2
                + ", B3=" + B3
                + ", A3=" + A3;
    }
}