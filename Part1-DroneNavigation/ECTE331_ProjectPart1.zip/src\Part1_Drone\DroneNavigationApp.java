package Part1_Drone;

import java.io.IOException;

public class DroneNavigationApp {
    public static void main(String[] args) {
        // If the user gives iterations, use it. Otherwise use 50.
        int iterations = args.length >= 1 ? Integer.parseInt(args[0]) : 50;

        // Print the program title and number of cycles.
        System.out.println("Fault-Tolerant Autonomous Drone Navigation System");
        System.out.println("Iterations=" + iterations);

        // Create the log file for this run.
        try (EventLog log = new EventLog("log.txt")) {
            // Save basic start information in the log file.
            log.write("SYSTEM", "Application started");
            log.write("SYSTEM", "Iterations=" + iterations);

            // Create the controller that handles sensors, voting, and reliability.
            DroneController controller = new DroneController(log);

            try {
                // The project hint asks for the processing loop inside this try block.
                for (int cycle = 1; cycle <= iterations; cycle++) {
                    // Process one sensor cycle.
                    int altitude = controller.processCycle(cycle);

                    // Print the final altitude selected for this cycle.
                    System.out.println("Output altitude supplied to drone controller: " + altitude + " m");

                    // Save the final altitude in the log file.
                    log.write("OUTPUT", "Output altitude supplied to drone controller: " + altitude + " m");
                }

                // This runs only if SAFE MODE was not triggered.
                log.write("SYSTEM", "Completed all cycles without SAFE MODE.");
                System.out.println("Completed all cycles without SAFE MODE.");

            } catch (SystemReliabilityException e) {
                // This runs when two reliability failures happen in a row.
                log.write("SAFE MODE", e.getMessage());
                log.write("SYSTEM", "Execution stopped as required.");

                // Print SAFE MODE message.
                System.out.println();
                System.out.println("SAFE MODE ACTIVATED: " + e.getMessage());
                System.out.println("Execution stopped as required. See log.txt for evidence.");
            }

        } catch (IOException e) {
            // This catches log file errors.
            System.err.println("Logging error: " + e.getMessage());
        }
    }
}

