package Part1_Drone;

import java.util.Random;

public class DroneSensor {
    private String name;
    private Random random;

    public DroneSensor(String name, Random random) {
        // This stores the sensor name, like Sensor A, Sensor B, or Sensor C.
        this.name = name;

        // This random object is used to simulate different sensor results.
        this.random = random;
    }

    public String getName() {
        // This returns the sensor name so it can be printed in the output.
        return name;
    }

    public int readSensor() throws SensorReadException {
        // chance decides if the sensor fails, gives corrupted data, or gives valid data.
        int chance = random.nextInt(100);

        // If chance is from 0 to 14, the sensor fails.
        // The project says this case should throw SensorReadException.
        if (chance < 15) {
            throw new SensorReadException(name + "=FAILURE");
        }

        // If chance is from 15 to 29, the sensor gives corrupted data.
        // Corrupted data must be outside the valid altitude range 0 to 200.
        if (chance < 30) {
            // This randomly chooses if the corrupted value is below 0 or above 200.
            if (random.nextBoolean()) {
                // Invalid low value.
                return -1 * (1 + random.nextInt(50));
            } else {
                // Invalid high value.
                return 201 + random.nextInt(50);
            }
        }

        // If chance is from 30 to 99, the sensor gives a valid altitude.
        // I used a baseline value near 100 meters to simulate normal drone altitude.
        int baselineValue = 100;

        // This gives a small range of values from 100 to 104.
        // This also helps the three sensors sometimes match for majority voting.
        int range = 5;

        // This returns the final valid altitude reading.
        return baselineValue + random.nextInt(range);
    }
}