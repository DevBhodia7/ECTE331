package Part1_Drone;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class DroneController {
    private DroneSensor sensorA;
    private DroneSensor sensorB;
    private DroneSensor sensorC;
    private EventLog log;

    private int previousValidAltitude;
    private int consecutiveFailures;

    public DroneController(EventLog log) {
        // This log object is used to save important events in log.txt.
        this.log = log;

        // Random is used to simulate the sensor behaviour required in the project.
        Random random = new Random();

        // These are the three redundant sensors used by the drone.
        sensorA = new DroneSensor("Sensor A", random);
        sensorB = new DroneSensor("Sensor B", random);
        sensorC = new DroneSensor("Sensor C", random);

        // This is the starting altitude used if the first cycle has no majority.
        previousValidAltitude = 100;

        // This counts reliability failures that happen one after another.
        consecutiveFailures = 0;
    }

    public int processCycle(int cycle) throws SystemReliabilityException {
        // This list stores the result from each sensor in the current cycle.
        List<SensorResult> results = new ArrayList<SensorResult>();

        // Read all three sensors.
        results.add(readOneSensor(sensorA));
        results.add(readOneSensor(sensorB));
        results.add(readOneSensor(sensorC));

        // Print and log all sensor values for this cycle.
        System.out.println();
        System.out.println("Cycle " + cycle + " sensor values: " + results);
        log.write("SENSORS", "Cycle " + cycle + " sensor values: " + results);

        // This list stores only valid sensor readings.
        List<Integer> validValues = new ArrayList<Integer>();

        // Corrupted and failed sensors are ignored here.
        for (SensorResult result : results) {
            if (result.isValid()) {
                validValues.add(result.getValue());
            }
        }

        // This checks if at least two valid sensors have the same value.
        Integer majorityValue = findMajority(validValues);

        // This becomes true if the system cannot fully trust the readings.
        boolean reliabilityFailure = false;

        // This is the altitude that will be sent to the drone controller.
        int finalAltitude;

        if (validValues.size() < 2) {
            // Fewer than two valid sensors means there is not enough good data.
            reliabilityFailure = true;

            // Use the previous valid altitude as fallback.
            finalAltitude = previousValidAltitude;

            System.out.println("Voting decision: fewer than 2 valid sensors -> fallback altitude = "
                    + finalAltitude + " m");
            log.write("VOTING", "Fewer than 2 valid sensors. Fallback altitude = "
                    + finalAltitude + " m");

        } else if (majorityValue != null) {
            // Two sensors agree, so that value is accepted.
            finalAltitude = majorityValue;

            // Save it as the latest good altitude.
            previousValidAltitude = finalAltitude;

            System.out.println("Voting decision: majority altitude = " + finalAltitude + " m");
            log.write("VOTING", "Majority altitude = " + finalAltitude + " m");

        } else {
            // No majority means the last valid altitude is used.
            reliabilityFailure = true;
            finalAltitude = previousValidAltitude;

            System.out.println("Voting decision: no majority -> fallback altitude = "
                    + finalAltitude + " m");
            log.write("VOTING", "No majority. Fallback altitude = " + finalAltitude + " m");
        }

        if (reliabilityFailure) {
            // Add one failure because this cycle was not fully reliable.
            consecutiveFailures++;

            System.out.println("Reliability status: FAILURE " + consecutiveFailures + "/2");
            log.write("RELIABILITY", "FAILURE " + consecutiveFailures + "/2");

        } else {
            // Reset the count because this cycle had a good majority.
            consecutiveFailures = 0;

            System.out.println("Reliability status: OK, consecutive failures reset to 0");
            log.write("RELIABILITY", "OK, consecutive failures reset to 0");
        }

        if (consecutiveFailures >= 2) {
            // The project requires SAFE MODE after two consecutive reliability failures.
            throw new SystemReliabilityException(
                    "Two consecutive reliability failures. Drone must enter SAFE MODE.");
        }

        // Return the selected altitude for this cycle.
        return finalAltitude;
    }

    private SensorResult readOneSensor(DroneSensor sensor) {
        try {
            // Try to read the sensor.
            int value = sensor.readSensor();

            if (value < 0 || value > 200) {
                // Any value outside 0 to 200 is corrupted.
                System.out.println("Corrupted event: " + sensor.getName()
                        + "=CORRUPTED(" + value + ")");

                log.write("CORRUPTED", sensor.getName() + " returned " + value);

                // Return a corrupted sensor result.
                return SensorResult.corrupted(sensor.getName(), value);
            }

            // The value is inside 0 to 200, so it is valid.
            return SensorResult.valid(sensor.getName(), value);

        } catch (SensorReadException e) {
            // This runs when the sensor throws a failure exception.
            System.out.println("Failure event: " + e.getMessage());
            log.write("FAILURE", e.getMessage());

            // Return a failed sensor result.
            return SensorResult.failure(sensor.getName());
        }
    }

    private Integer findMajority(List<Integer> values) {
        // Compare every valid value with the other valid values.
        for (int i = 0; i < values.size(); i++) {
            for (int j = i + 1; j < values.size(); j++) {
                // If two values are equal, this is the majority value.
                if (values.get(i).intValue() == values.get(j).intValue()) {
                    return values.get(i);
                }
            }
        }

        // Return null when no two valid sensors agree.
        return null;
    }
}