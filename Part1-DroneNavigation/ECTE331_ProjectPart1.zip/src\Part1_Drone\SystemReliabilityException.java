package Part1_Drone;

public class SystemReliabilityException extends Exception {
    // This ID is added because this class extends Exception.
    private static final long serialVersionUID = 1L;

    public SystemReliabilityException(String message) {
        // Send the SAFE MODE message to the parent Exception class.
        super(message);
    }
}