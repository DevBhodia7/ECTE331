package Part1_Drone;

import java.io.IOException;

public class SensorReadException extends IOException {
    // This ID is added because this exception class extends IOException.
    private static final long serialVersionUID = 1L;

    public SensorReadException(String message) {
        // Send the error message to the parent IOException class.
        super(message);
    }
}