package Part1_Drone;

import java.io.Closeable;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class EventLog implements Closeable {
    // This format is used to add date and time to each log line.
    private static final DateTimeFormatter FORMAT =
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");

    // PrintWriter is used to write text into log.txt.
    private final PrintWriter writer;

    public EventLog(String fileName) throws IOException {
        // false means a new run starts a fresh log file.
        // Old log content is replaced when the program runs again.
        this.writer = new PrintWriter(new FileWriter(fileName, false));
    }

    public synchronized void write(String eventType, String details) {
        // synchronized makes sure only one write happens at a time.
        // This is useful if more than one part of the program writes to the log.

        // Write one formatted line to log.txt.
        writer.printf("%s | %-22s | %s%n",
                LocalDateTime.now().format(FORMAT),
                eventType,
                details);

        // flush saves the message immediately instead of waiting.
        writer.flush();
    }

    @Override
    public void close() {
        // Close the file when the program is finished.
        writer.close();
    }
}