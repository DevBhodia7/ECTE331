package Part1_Drone;

public class SensorResult {
    // This stores the sensor name, like Sensor A, Sensor B, or Sensor C.
    private String sensorName;

    // This stores the sensor reading value.
    // Integer is used because failed sensors do not have a value.
    private Integer value;

    // These booleans tell what type of result the sensor gave.
    private boolean valid;
    private boolean corrupted;
    private boolean failure;

    private SensorResult(String sensorName, Integer value, boolean valid,
                         boolean corrupted, boolean failure) {
        // Store all details for this sensor result.
        this.sensorName = sensorName;
        this.value = value;
        this.valid = valid;
        this.corrupted = corrupted;
        this.failure = failure;
    }

    public static SensorResult valid(String sensorName, int value) {
        // Create a result for a valid sensor reading.
        return new SensorResult(sensorName, value, true, false, false);
    }

    public static SensorResult corrupted(String sensorName, int value) {
        // Create a result for a corrupted reading.
        return new SensorResult(sensorName, value, false, true, false);
    }

    public static SensorResult failure(String sensorName) {
        // Create a result for a failed sensor.
        // The value is null because the sensor did not return a reading.
        return new SensorResult(sensorName, null, false, false, true);
    }

    public String getSensorName() {
        // Return the name of the sensor.
        return sensorName;
    }

    public int getValue() {
        // Return the sensor value.
        // This should only be called when the result is valid.
        return value;
    }

    public boolean isValid() {
        // Return true if this is a valid reading.
        return valid;
    }

    public boolean isCorrupted() {
        // Return true if this is a corrupted reading.
        return corrupted;
    }

    public boolean isFailure() {
        // Return true if this is a failed sensor reading.
        return failure;
    }

    @Override
    public String toString() {
        // This controls how the result is printed in the console.

        if (valid) {
            // Print normal valid reading.
            return sensorName + "=" + value;
        }

        if (corrupted) {
            // Print corrupted reading with its invalid value.
            return sensorName + "=CORRUPTED(" + value + ")";
        }

        // Print failed sensor.
        return sensorName + "=FAILURE";
    }
}