package Part3_RoboticArm;

//I use this class to store the timing result of one run.
public class RunResult {
 private long waitingTime;
 private long responseTime;

 public RunResult(long waitingTime, long responseTime) {
     this.waitingTime = waitingTime;
     this.responseTime = responseTime;
 }

 // This returns how long the high priority task waited for the motor.
 public long getWaitingTime() {
     return waitingTime;
 }

 // This returns the full response time of the high priority task.
 public long getResponseTime() {
     return responseTime;
 }
}