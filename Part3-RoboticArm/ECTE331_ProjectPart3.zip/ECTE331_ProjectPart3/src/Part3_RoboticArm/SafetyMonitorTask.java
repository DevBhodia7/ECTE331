package Part3_RoboticArm;

//This is the high priority thread.
public class SafetyMonitorTask extends Thread {
 private MotorController motor;
 private RunResult result;

 public SafetyMonitorTask(MotorController motor) {
     super("SafetyMonitor-High");
     this.motor = motor;

     // Safety Monitor has the highest priority because it handles emergencies.
     setPriority(Thread.MAX_PRIORITY);
 }

 @Override
 public void run() {
     try {
         // Response time starts before trying to access the motor.
         long startResponse = System.currentTimeMillis();

         // true means this is the high priority task.
         long waitingTime = motor.enter("Safety Monitor", true);

         // This simulates stopping or checking the robotic arm.
         motor.useMotor("Safety Monitor", 120);

         // The safety task releases the motor.
         motor.leave("Safety Monitor");

         // Response time includes waiting and motor usage time.
         long responseTime = System.currentTimeMillis() - startResponse;

         // I store the result so main can calculate averages.
         result = new RunResult(waitingTime, responseTime);
     } catch (InterruptedException e) {
         interrupt();
     }
 }

 // Main uses this after join() to read the measured timing.
 public RunResult getResult() {
     return result;
 }
}