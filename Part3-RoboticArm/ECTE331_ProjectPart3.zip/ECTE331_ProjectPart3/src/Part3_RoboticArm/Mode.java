package Part3_RoboticArm;

//I use this enum to choose which priority management case is running.
public enum Mode {
 BASELINE,
 INHERITANCE,
 CEILING
}