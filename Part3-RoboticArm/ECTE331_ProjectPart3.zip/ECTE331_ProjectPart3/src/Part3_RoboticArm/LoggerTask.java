package Part3_RoboticArm;

//This is the low priority thread.
public class LoggerTask extends Thread {
 private MotorController motor;
 private Mode mode;

 public LoggerTask(MotorController motor, Mode mode) {
     super("Logger-Low");
     this.motor = motor;
     this.mode = mode;

     // Logger has the lowest priority in the system.
     setPriority(Thread.MIN_PRIORITY);
 }

 @Override
 public void run() {
     try {
         // Logger tries to access the shared motor.
         motor.enter("Logger", false);

         // Baseline is longer so priority inversion is easier to see.
         if (mode == Mode.BASELINE) {
             motor.useMotor("Logger", 600);
         } else {
             motor.useMotor("Logger", 300);
         }

         // Logger releases the motor after finishing.
         motor.leave("Logger");
     } catch (InterruptedException e) {
         // I interrupt again so Java knows this thread was interrupted.
         interrupt();
     }
 }
}