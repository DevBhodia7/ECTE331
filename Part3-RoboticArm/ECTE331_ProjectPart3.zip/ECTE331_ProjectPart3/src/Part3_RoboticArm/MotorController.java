package Part3_RoboticArm;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

// This class is the shared resource used by all three threads.
public class MotorController {
    private boolean inUse = false;
    private Thread owner = null;
    private int originalPriority = Thread.NORM_PRIORITY;
    private Mode mode;

    // I use this format so the timestamps look readable in the console.
    private static final DateTimeFormatter TIME_FORMAT =
            DateTimeFormatter.ofPattern("HH:mm:ss.SSS");

    public MotorController(Mode mode) {
        this.mode = mode;
    }

    // This method lets a thread enter the critical section.
    public synchronized long enter(String taskName, boolean isHighPriority) throws InterruptedException {
        long startWaiting = System.currentTimeMillis();

        // If another thread is using the motor, this thread must wait.
        while (inUse) {
            print(taskName + " is BLOCKED. MotorController is currently used by " + owner.getName());

            // In inheritance mode, the lower-priority owner temporarily gets high priority.
            if (mode == Mode.INHERITANCE && isHighPriority && owner.getPriority() < Thread.MAX_PRIORITY) {
                print("Priority inheritance applied to " + owner.getName());
                owner.setPriority(Thread.MAX_PRIORITY);
            }

            // I use wait() here so the thread blocks instead of wasting CPU time.
            wait();
        }

        // Now this thread owns the motor.
        inUse = true;
        owner = Thread.currentThread();
        originalPriority = owner.getPriority();

        // In ceiling mode, any thread entering the motor gets the ceiling priority.
        if (mode == Mode.CEILING) {
            print("Priority ceiling applied to " + owner.getName());
            owner.setPriority(Thread.MAX_PRIORITY);
        }

        long waitingTime = System.currentTimeMillis() - startWaiting;
        print(taskName + " ENTERED MotorController after waiting " + waitingTime + " ms");

        return waitingTime;
    }

    // This method releases the shared motor.
    public synchronized void leave(String taskName) {
        // I restore the priority after the thread leaves the critical section.
        if (mode == Mode.INHERITANCE || mode == Mode.CEILING) {
            owner.setPriority(originalPriority);
            print(taskName + " priority restored");
        }

        print(taskName + " LEFT MotorController");

        // The motor is now free for another waiting thread.
        inUse = false;
        owner = null;

        // This wakes up any thread waiting for the motor.
        notifyAll();
    }

    // This simulates time spent using the robotic arm motor.
    public void useMotor(String taskName, int timeMs) throws InterruptedException {
        print(taskName + " is using the robotic arm motor");
        Thread.sleep(timeMs);
    }

    // This prints messages with normal readable timestamps.
    public static void print(String message) {
        String time = LocalTime.now().format(TIME_FORMAT);
        System.out.println("[" + time + "] " + message);
    }
}