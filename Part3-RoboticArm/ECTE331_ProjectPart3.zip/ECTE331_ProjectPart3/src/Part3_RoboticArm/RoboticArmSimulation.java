package Part3_RoboticArm;

//This is the main class that runs all three cases.
public class RoboticArmSimulation {
 public static void main(String[] args) throws InterruptedException {
     int runs = 5;

     // I allow the user to choose how many runs to test.
     if (args.length > 0) {
         runs = Integer.parseInt(args[0]);
     }

     System.out.println("Real-Time Robotic Arm Controller");
     System.out.println("Runs per mode = " + runs);
     System.out.println();

     // I test the three required cases from the project sheet.
     testMode(Mode.BASELINE, runs);
     testMode(Mode.INHERITANCE, runs);
     testMode(Mode.CEILING, runs);
 }

 // This method runs one mode several times and calculates the averages.
 private static void testMode(Mode mode, int runs) throws InterruptedException {
     long totalWaiting = 0;
     long totalResponse = 0;

     System.out.println();
     System.out.println("Test " + getTestNumber(mode) + ": " + getModeName(mode));
     
     for (int i = 1; i <= runs; i++) {
         System.out.println("--- Run " + i + " ---");

         // Each run gets a new motor so the state starts clean.
         MotorController motor = new MotorController(mode);

         // I create the three real-time tasks.
         LoggerTask logger = new LoggerTask(motor, mode);
         SafetyMonitorTask safety = new SafetyMonitorTask(motor);
         MotionPlannerTask planner = new MotionPlannerTask(motor, mode);

         // Logger starts first so the low priority thread gets the motor.
         logger.start();
         Thread.sleep(50);

         // Safety starts second and should become blocked by Logger.
         safety.start();
         Thread.sleep(50);

         // Motion Planner starts after Safety to demonstrate the medium priority effect.
         planner.start();

         // I wait for all threads to finish before reading the result.
         logger.join();
         safety.join();
         planner.join();

         RunResult result = safety.getResult();

         totalWaiting += result.getWaitingTime();
         totalResponse += result.getResponseTime();

         System.out.println("High priority waiting time = " + result.getWaitingTime() + " ms");
         System.out.println("High priority response time = " + result.getResponseTime() + " ms");
         System.out.println();
     }

     long averageWaiting = totalWaiting / runs;
     long averageResponse = totalResponse / runs;

     // These averages are used for the performance evaluation.
     System.out.println("Average waiting time for " + mode + " = " + averageWaiting + " ms");
     System.out.println("Average response time for " + mode + " = " + averageResponse + " ms");

     // This is a simple text graph, so no third-party library is needed.
     printBar("Waiting graph", averageWaiting);
     System.out.println();
 }

 // I use a simple console graph because the project asks for graphical results.
 private static void printBar(String label, long value) {
     System.out.print(label + ": ");

     for (int i = 0; i < value / 20; i++) {
         System.out.print("DB");
     }

     System.out.println(" " + value + " ms");
 }

 // I use this to print the tests in a simple 1, 2, 3 order.
 private static int getTestNumber(Mode mode) {
     if (mode == Mode.BASELINE) {
         return 1;
     } else if (mode == Mode.INHERITANCE) {
         return 2;
     } else {
         return 3;
     }
 }

 // I use this to print normal test names instead of enum names.
 private static String getModeName(Mode mode) {
     if (mode == Mode.BASELINE) {
         return "No priority management";
     } else if (mode == Mode.INHERITANCE) {
         return "Priority inheritance";
     } else {
         return "Priority ceiling";
     }
 }
}