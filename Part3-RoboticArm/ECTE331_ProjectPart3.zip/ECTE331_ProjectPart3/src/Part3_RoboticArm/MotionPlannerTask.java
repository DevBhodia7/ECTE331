package Part3_RoboticArm;

//This is the medium priority thread.
public class MotionPlannerTask extends Thread {
 private MotorController motor;
 private Mode mode;

 public MotionPlannerTask(MotorController motor, Mode mode) {
     super("MotionPlanner-Medium");
     this.motor = motor;
     this.mode = mode;

     // Motion Planner has medium priority.
     setPriority(Thread.NORM_PRIORITY);
 }

 @Override
 public void run() {
     try {
         // In baseline mode, this shows the medium task delaying the high task.
         if (mode == Mode.BASELINE) {
             MotorController.print("Motion Planner is running while Safety Monitor is waiting");
             Thread.sleep(250);
         }

         // Motion Planner also needs the shared motor.
         motor.enter("Motion Planner", false);

         // This simulates sending movement commands to the motor.
         motor.useMotor("Motion Planner", 100);

         // Motion Planner releases the motor.
         motor.leave("Motion Planner");
     } catch (InterruptedException e) {
         interrupt();
     }
 }
}